# Joshua Ginn, A6, CIS345, 10:30am

from tkinter import *
from tkinter import ttk

# import student_classes
# from student_classes import Student, GradStudent


def save_student_click():
    print('Nice')

# Unable to have Functions called. Only Gui set up use place()

#     stype = radio_button.get()
#     fntype = first_name_entry.get()
#     lntype = last_name_entry.get()
#     majortype = major_combo_box.get()
#     thesistype = thesis_lbl_entry.get()
#
#     if stype == 'G':
#         new_student = student_classes.GradStudent
#         new_student.fname = fntype
#         new_student.lname = lntype
#         new_student.major = majortype
#         new_student.thesis = thesistype
#     else:
#         new_student = student_classes.Student
#         new_student.lname = fntype
#         new_student.fname = lntype
#         new_student.major = majortype
#
#     if edit_mode:
#         student_roster[edit_index] = new_student
#         listbox.delete(edit_index)
#         listbox.deleteinsert(index, new_student)
#         edit_mode = False
#     else:
#         student_roster.append(new_student)
#         listbox.insert(END, new_student)


window = Tk()
window.geometry('400x500')
window.title('Student Entry Form')
window.config(bg='#93c5ed')


student_type_box = Frame(window, bg='#faebd7', width='300', height='80', borderwidth=1,
                         relief=SUNKEN)
student_type_box.place(x=50, y=15)   # needs help
# student_type_box.grid_propagate(0)

student_type_label = Label(student_type_box, text="Student Type").place(x=0, y=0)

var = StringVar()
var.set("S")

radio_button = Radiobutton(student_type_box, bg='#faebd7', text="Student", value="S", variable=var,
                           justify=LEFT, command=save_student_click).place(x=15, y=30)
radio_button = Radiobutton(student_type_box, bg='#faebd7', text="Graduate Student", value="G", variable=var,
                           justify=RIGHT, command=save_student_click).place(x=115, y=30)

first_name = StringVar()
last_name = StringVar()
thesis = StringVar()

first_name_lbl = Label(window, bg="#93c5ed", justify=CENTER, width=10, text="First Name:").place(x=75, y=120)
first_name_entry = Entry(window, bg="white", justify=LEFT, width=28, textvariable=first_name).place(x=179, y=120)

last_name_lbl = Label(window, bg="#93c5ed", justify=CENTER, width=10, text="Last Name:").place(x=75, y=155)
last_name_entry = Entry(window, bg="white", justify=LEFT, width=28, textvariable=last_name).place(x=179, y=155)

majors = ['ACC', 'BDA', 'CIS', 'SCM', 'FIN']
major_lbl = Label(window, bg="#93c5ed", justify=CENTER, width=10, text="Major:").place(x=75, y=190)
major_combo_box = ttk.Combobox(window, width=25, values=majors).place(x=179, y=190)

thesis_lbl = Label(window, bg="#93c5ed", justify=CENTER, width=10, text="Thesis:").place(x=75, y=225)
thesis_lbl_entry = Entry(window, bg="white", justify=LEFT, width=28, textvariable=thesis).place(x=179, y=225)

save_student_button = Button(window, text="Save Student").place(x=271, y=260)

double_click_lbl = Label(window, text="(Double-Click to Edit a Student)", bg="#93c5ed").place(x=50, y=280)

listbox = Listbox(window, width=49).place(x=50, y=300)

# student_roster = []  # List of all student Objects added to listbox
# edit_mode = False  # Determines how save button works
# edit_index = {0}  # Stores the ndex of the student double clicked in listbox
# student_type = StringVar

# student_type_box.rowconfigure(0, weight=1)
# student_type_box.rowconfigure(1, weight=1)
# student_type_box.rowconfigure(2, weight=1)
# student_type_box.rowconfigure(3, weight=1)
#
# student_type_box.columnconfigure(0, weight=1)
# student_type_box.columnconfigure(1, weight=4)
# student_type_box.columnconfigure(2, weight=1)
# student_type_box.columnconfigure(3, weight=1)

mainloop()

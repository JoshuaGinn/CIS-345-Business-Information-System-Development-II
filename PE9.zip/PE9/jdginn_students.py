# Joshua Ginn   CIS345  10:30am    E9

#TODO: Student class
class Student:

    def __init__(self, first=''):
        self.__fname = first;
        self.__lname = "";

    @property
    def fname(self):
        return self.__fname.capitalize()

    @property
    def lname(self):
        return self.__lname.capitalize()


    @fname.setter
    def fname(self, new):
        if new.isalpha() and len(new) >= 1:
            self.__fname=new
        else:
            self.__fname='Unkown'

    @lname.setter
    def lname(self, new):
        if new.isalpha() and len(new) >= 1:
            self.__lname = new
        else:
            self.__lname = 'Unkown'

    def __str__(self):
        return f'{self.__fname} {self.__lname}'



#TODO: GradStudent class
class GradStudent(Student):
    """Extend student and add data to it."""
    def __init__(self, thesis, fname=''):

        super().__init__(fname)
        self.thesis = thesis

    @property
    def thesis(self):
        return self.thesis.capitalize()

    @thesis.setter
    def thesis(self, new):
        if self.isalpha() and len(self) >= 1:
            self.thesis = f'Thesis: {new}'
        else:
            self.thesis = f'Thesis: Unknown'


    def __str__(self):
        return f'{self}\n\t{self.thesis}'


#TODO: PhDStudent class
class PhDStudent(Student):
    def __init__(self, dissertation, fname=''):

        super().__init__(fname)
        self.__dissertation = dissertation

    @property
    def dissertation(self):
        return self.dissertation.capitalize()

    @dissertation.setter
    def dissertation(self, new):
        if new.isalpha() and len(new) >= 1:
            self.dissertation = f'Dissertation: {new}'
        else:
            self.dissertation = f'Dissertation: Unknown'


def add_student(studentType):
    """Get student data and create an object to be returned"""
    student = None
    # Get first and last name here because all students need this data
    first = input('Enter first name: ')
    last = input('Enter last name: ')

    #TODO: Determine student type and construct an object and save in student
    if studentType == 'G':
        thesis_title = input('Enter thesis title: ').upper()
        student = GradStudent
    elif studentType == 'S':
        student = Student
    elif studentType == 'p':
        dissertation_title = input('Enter dissertation title: ').upper()
        student = PhDStudent

    #TODO: Assign last_name using our object's property then return student
    student.lname = last
    return student

# Main Function
def main():
    """Main program logic"""
    students = []
    entry = ''
    print("{:^50}".format('Student Management System'))

    while entry != 'X':
        studentTypes = ['S', 'G', 'P']
        # Get user entry and capitalize the entry
        entry = input(
            '\nEnter (S)tudent, (G)radStudent, (P)hDStudent or (X)exit: ')
        entry = entry.upper()

        #TODO: Is user entry one of studentTypes. Yes - add_student to list

        if entry in studentTypes:
            new_student = add_student(entry)
            students.append(new_student)

    #TODO: print students and dissertation if the student is a PhD type
    print("\nThe following students were added...")
    for student in students:
        print(f'{student}')

    if student(Student, PhDStudent):
        print(f'\t {student.dissertation}')

if __name__ == "__main__":
    # call and execute the main function
    main()

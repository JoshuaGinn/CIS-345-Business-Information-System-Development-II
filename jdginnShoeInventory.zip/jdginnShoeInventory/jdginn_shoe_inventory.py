# Joshua Ginn, Project GUI, CIS345, 10:30am

from tkinter import *
# from tkinter import ttk
from PIL import Image, ImageTk

available_brands = ['Asics', 'Brooks', 'Hoka', 'New Balance', 'Nike', 'Saucony']


def close():
    window.destroy()


window = Tk()
window.geometry('800x500')
window.resizable(width=0, height=0)
window.title('Student Entry Form')
window.config(bg='#93c5ed')


inventory_list_box = Frame(window, bg='#faebd7', width='380', height='465', borderwidth=1, relief=SUNKEN)
inventory_list_box.place(x=400, y=15)

output_example_lbl = Label(window, bg='#faebd7', text=' Brand\tModel\tColor\tMSRP\tGender\tLocation\t Size ',
                           font=('Arial', 10), relief='solid')
output_example_lbl.place(x=402, y=17)


canvas = Canvas(window, bg="tan", width=365, height=365)
canvas.place(x=22, y=112)

runner = Image.open('runners.jpg')
img = runner.resize((250, 85), Image.ANTIALIAS)
img.save('runners.png')
logo = ImageTk.PhotoImage(img)
logo_label = Label(image=logo, borderwidth=1, relief=FLAT)
logo_label.image = logo
logo_label.place(x=135, y=15)


app_title_lbl = Label(window, text='Shoe\nInventory\nTracker', bg='#93c5ed', font=('Arial', 19), justify="right")
app_title_lbl.place(x=20, y=15)

brand_lbl = Label(window, text='Brand:\n\nModel:\n\nMSRP:\n\nGender:\n\nColor:\n\nLocation:\n\nSize:', bg='tan',
                  font=('Arial', 13), justify='right')
brand_lbl.place(x=50, y=130)


brands = StringVar()
brands.set(available_brands[0])

brand_selector = OptionMenu(window, brands, *available_brands)
brand_selector.config(width=28)
brand_selector.place(x=150, y=125)

model = StringVar()
model_entry = Entry(window, textvariable=model, width=26, font=('Arial', 13)).place(x=135, y=167)


msrp = StringVar()
msrp_entry = Entry(window, textvariable=msrp, width=26, font=('Arial', 13)).place(x=135, y=206)


gender = StringVar()
gender.set("M")
mens = Radiobutton(window, text="Men's", variable=gender, value='M', bg='tan').place(x=160, y=246)
womens = Radiobutton(window, text="Women's", variable=gender, value='F', bg='tan').place(x=235, y=246)

color = StringVar()
color_entry = Entry(window, textvariable=color, width=26, font=('Arial', 13)).place(x=135, y=282)

location = StringVar()
location.set("G")
glendale = Radiobutton(window, text="Glendale", variable=location, value='G', bg='tan').place(x=135, y=320)
tempe = Radiobutton(window, text="Tempe", variable=location, value='T', bg='tan').place(x=215, y=320)
scottsdale = Radiobutton(window, text="Scottsdale", variable=location, value='S', bg='tan').place(x=280, y=320)

size = IntVar()
size.set('')
size_entry = Entry(window, textvariable=size, width=26, font=('Arial', 13)).place(x=135, y=360)

add_btn = Button(window, width=8, text="Add", command="add", font=('Arial', 11)).place(x=45, y=420)
delete_btn = Button(window, width=8, text="Delete", command="Delete", font=('Arial', 11)).place(x=160, y=420)
exit_btn = Button(window, width=8, text="Exit", command=close, font=('Arial', 11)).place(x=275, y=420)


mainloop()

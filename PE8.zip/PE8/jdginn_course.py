# Joshua Ginn   CIS345  10:30am    E8

# 1 Import 2 modules
import random
import statistics

# 2. Declare blank list.
courses = []


# 3. Define Class course with items listed from UML
class Course:
    """ """

    dept = 'CIS'

    def __init__(self, num, grades):
        """ Setup Initial values for course exam grades"""
        self._number = num
        self._name = self.dept + num
        self.grades = grades

    # 1. Create a Property for name and number
    @property
    def name(self):
        return self._name

    @property
    def number(self):
        return self._number

    @number.setter
    def number(self, num):
        self._number = num
        # self._name = name.upper() + num

    @name.setter
    def name(self, name):
        self._name = name.upper()

    # 3. Define a ClassMethod
    @classmethod
    def change_department(cls, new_dept):
        """Class method to modify class variable dept"""
        cls.dept = new_dept

    # 4. Define an Instance Method
    def display_class_average(self):

        for k, v in grades.items():
            # avg = sum(v) / float(len(v))

            avg = statistics.mean(v)
            print(f'{k} avg is {avg:.1f} - {v}')


# 5. Create a Boolean var to control a while loop.
print(f'\tEntering course information...\n')
add_course = True
while add_course:

    course_number = input(f'Enter course number: {Course.dept}')
    grades = dict()

    grades['Exam'] = [random.randint(1, 100), random.randint(1, 100), random.randint(1, 100)]
    grades['Quiz'] = [random.randint(1, 100), random.randint(1, 100), random.randint(1, 100)]

    this_course = Course(course_number, grades)
    courses.append(this_course)

    another_one = input(f'\nAdd another course (Y/N)? ').casefold()

    if another_one == 'y':
        Course.change_department(input('Enter 3 letter department for the next course: ').upper())
    else:
        add_course = False

print('\nPrinting Courses')

for course in courses:
    print(f'\nCourse: {course.name}:')
    Course.display_class_average(course)

# Joshua Ginn, CIS345, 10:30am, PE11

from tkinter import *


from PIL import Image, ImageTk


orders = []

win = Tk()

win.title('Greeting')
win.geometry('400x600')
win.columnconfigure(0, weight=1) #content displayed in center
win.config(bg='black')

check_var1 = IntVar()
check_var2 = IntVar()
check_var3 = IntVar()
check_var4 = IntVar()
check_var5 = IntVar()
check_var6 = IntVar()
check_var7 = IntVar()
check_var8 = IntVar()

canvas = Canvas(win, width=300, height=180, bg='black')
canvas.place(x=10, y=10)

# logo = Image.open('imageoftree.jpg')
# logo = ImageTk.PhotoImage(logo)
# logo_label = Label(image=logo)
# logo_label.image = logo
# logo_label.grid(columnspan=3, column=0, row=0, pady=10)

logo = Image.open('imageoftree.jpg')
new_width = 300
new_height = 150
img = logo.resize((new_width, new_height), Image.ANTIALIAS)
img.save('imageoftree.png')
logo = ImageTk.PhotoImage(img)
logo_label = Label(image=logo)
logo_label.image = logo
logo_label.place(x=48, y=25)

welcome = Label(win, bg='grey', width=200, font=("Courier", 12))
welcome.grid(columnspan=3, column=0, row=0, pady=10)
price_info = Label(win, bg='grey', width=200, font=("Courier", 12))

box1 = Frame(win, bg='white', width=280, height=120, borderwidth=5, relief=RIDGE)
box1.place(x=150, y=100)
box1.grid_propagate(False)
box1.columnconfigure(0, weight=1)
box1.columnconfigure(1, weight=1)
box1.rowconfigure(0, weight=1)
box1.rowconfigure(0, weight=2)
box1.rowconfigure(0, weight=3)
box1.rowconfigure(0, weight=4)

c1 = Checkbutton(box1, text="Iced Mint Mojito", fg='#6f4e37', bd=10, variable=check_var1, font=("Arial", 8),
                 onvalue=1, offvalue=0)
c1.grid(row=1, column=0, pady=2, sticky=W)

c2 = Checkbutton(box1, text="Iced Black", fg='#6f4e37', bd=10, variable=check_var2, font=("Arial", 8),
                 onvalue=2, offvalue=0)
c2.grid(row=2, column=0, pady=2, sticky=W)


c3 = Checkbutton(box1, text="Bottle Burger", fg='#6f4e37', bd=10, variable=check_var3, font=("Arial", 8),
                 onvalue=3, offvalue=0)
c3.grid(row=3, column=0, pady=2, sticky=W)


c4 = Checkbutton(box1, text="Bottle Ice Cream", fg='#6f4e37', bd=10, variable=check_var4, font=("Arial", 8),
                 onvalue=4, offvalue=0)
c4.grid(row=4, column=0, pady=2, sticky=W)


c5 = Checkbutton(box1, text="Iced Samatra", fg='#6f4e37', bd=10, variable=check_var5, font=("Arial", 8),
                 onvalue=5, offvalue=0)
c5.grid(row=1, column=1, pady=2, sticky=W)


c6 = Checkbutton(box1, text="Hot Black", fg='#6f4e37', bd=10, variable=check_var6, font=("Arial", 8),
                 onvalue=6, offvalue=0)
c6.grid(row=2, column=1, pady=2, sticky=W)


c7 = Checkbutton(box1, text="Bottle Fries", fg='#6f4e37', bd=10, variable=check_var7, font=("Arial", 8),
                 onvalue=7, offvalue=0)
c7.grid(row=3, column=1, pady=2, sticky=W)


c8 = Checkbutton(box1, text="Bottle Muffin", fg='#6f4e37', bd=10, variable=check_var8, font=("Arial", 8),
                 onvalue=8, offvalue=0)
c2.grid(row=4, column=1, pady=2, sticky=W)


name = Label(win, text='Enter your name: ', width=30, font=("Courier", 12), fg='blue')

submit_button = Button(win, font=("Arial", 16), text='Submit', width=10)
submit_button.grid(column=0, row=10, pady=20, padx=(35, 0), sticky=W)

exit_button = Button(win, font=("Arial", 16), text='Exit', width=10)
exit_button.grid(column=1, row=10, pady=20, padx=(35, 0), sticky=W)



mainloop()

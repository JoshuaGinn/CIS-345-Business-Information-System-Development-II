# Joshua Ginn, A5, CIS345, 10:30am

class Employee:

    def __init__(self, name, eid):
        self.name = name
        self.eid = eid

    @property
    def name(self):
        return self._name.upper()

    @name.setter
    def name(self, new_name):
        if new_name.isalpha() and len(new_name) >= 1:
            self._name = new_name
        else:
            self._name = 'Unkown'

    @property
    def eid(self):
        return self._eid

    @eid.setter
    def eid(self, new_eid):
        if len(new_eid) == 0:
            self._eid = "9999"
        elif len(new_eid) < 4:
            remainder = 4 - len(new_eid)
            for i in range(remainder):
                new_eid =+ "9"
            self._eid = new_eid
        else:
            self._eid = new_eid

    def __str__(self):
        return f'{self.eid}: {self.name}'

class Manager(Employee):

    def __init__(self, name, eid):
        super().__init__("manager")
        self._name = name
        self._eid = eid
        self.subordinates = []

    def add_subordinates(self):

        name = input("Enter subordinate name: ")
        eid = input("Enter subordinate id: ")


        new_employee = Employee(name, eid)
        self.subordinates.append(new_employee)

    def print_subordinates(self):
        for employee in self.subordinates:
            print(f'{employee}')

def main():

    employees = []
    print(f'Adding Employees...')

    add_more = 'y'
    while add_more == 'y':
        new_employee = add_employee()
        add_more = input(f'Do you want to enter more? ').lower()
    else:
        print(f'Printing Employee List')
        for employee in employees:
            print(employee)


def add_employee():

    name = input("Enter name: ")
    eid = input("Enter id: ")
    manager = input("Is the employee a manager? (Y/N) ").lower()
    if manager == 'y':
        new_employee = Manager(name, eid)
        subs = input(f'How many subordinates? ')
        for i in range(subs):
            new_employee.add_subordinates()
    elif manager == 'n':
        new_employee = Employee(name, eid)

    return new_employee



# calling main()
main()
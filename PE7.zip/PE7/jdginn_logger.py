# Joshua Ginn   CIS345  10:30am    E7

import random
import csv
from os import path


def log_transactions(logger):
    """ Writes transactions to CSV file
    :param logger, the logger:
    :return:
    """
    if not path.isfile('transactions.cvs'):
        with open('transactions.csv', 'w', newline='') as fp:
            data = csv.writer(fp)
            data.writerow(['DateTime', 'Username', 'Old Balance', 'Transaction Amount', 'New Balance'])

    # I have tried debugging. CSV file prints over last row, not collecting any further data(only last transaction)
    with open('transactions.csv', 'a', newline='') as fp:
        data = csv.writer(fp)
        data.writerow(logger)


def create_pin(username):
    """Returns user inputted pin or randomly generated pin"""
    ans1 = int(input('Enter 1 to create a pin yourself or 2 and the system will create a pin for you: '))

    # Allow 3 invalid pin entries

    max_tries = 3
    pin_tries = 1

    # print(ans1)
    if ans1 == 1:
        while pin_tries <= max_tries:

            pin = int(input('Select a number between 1 and 9999 as your pin: '))
            print(pin)
            if (pin > 0) and (pin < 10000):
                pin_found = True
                pin_tries = max_tries + 1
            else:
                print(f'Invalid pin. Attempt {pin_tries} of 3. Please try again')
                pin_tries += 1
                if pin_tries > max_tries:
                    print('Please try later ....')
                    pin_tries = max_tries + 1
    elif ans1 == 2:
        pin = random.randint(1, 9999)
        print("Your pin is: ", pin)
        pin_tries = 1
        pin_found = True
    else:
        print('Invalid option! Thank you for visiting Cactus Bank.  Come back soon.')
        pin_tries = max_tries + 1
    return pin


def format_money(num):
    """ Formats in to currency format ($ , .00)
    :param num:
    :return:
    """
    return f'${num:,.2f}'

# Joshua Ginn   CIS345  10:30am    E7

import os.path
import json
import time

import jdginn_logger
from jdginn_logger import format_money
# from jdginn_logger import log_transactions
from jdginn_logger import create_pin

from functools import wraps

import statistics


def line(func):
    """Outer Function"""
    @wraps(func)
    def wrapper(*args, **kwargs):
        """Wrapper Function"""
        title = func(*args,**kwargs)
        print(f'🌵{title:<60}🌵')
    return wrapper

@line
def title1(border):
    """Top/ Bottom borders."""
    return f'{border:.^60}'

@line
def title2():
    """ centered Welcome"""
    return '  Welcome to Cactus Bank, serving Arizona for 25 years!'

@line
def title3(title):
    """Centered Title"""
    return f'  {title}'


# Lambda expression to format to a dollar amount.
# dollar_formatter = lambda amt: f'${num:,.2f}'


# Used as parameter for CSV file append function.
logger = []

# used for confirming pin has been created
pin_created = False

# use the open command to open the file
with open('customers.json') as fp:
    data = json.load(fp)

# Bank Menu with 1-4 options
title1('🌵')
title2()
title3('')
title3('Enter 1 to add a new customer')
title3('Enter 2 to delete a customer')
title3('Enter 3 to make transactions')
title3('Enter 4 to exit the application')
title1('🌵')

# Error that pin could be undefined, fixed with declaring pin as anything.
pin = int

# Using Walrus Operator, set last value as selection to always return true upon any selection.
print((selection := input('Please enter your selection: ')) == selection)
# selection = input('🌵  Selection: ')

print()

# Add new Customer
if selection == '1':

    newUser = {}
    username = input(f'Please enter a username: ')
    name = input(f'Please enter your first and last name: ')
    while not pin_created:
        pin = create_pin(username)
        if (pin > 0) and (pin < 10000):
            pin_created = True
        else:
            ans1 = input(f'Would you like to enter a new pin?')
            if ans1 == 'y':
                create_pin(username)
                print(f'You will need to visit the system again to make transactions.')
                input('Press enter to continue')
            else:
                print(f'No pin, No account. Sorry.')

    checking = int(input(f'Enter the amount to be deposited into checking: '))
    savings = int(input(f'Enter the amount to be deposited into savings: '))

    newUser[username] = {'pin': int(pin), "Name": name, "C": checking, "S": savings}
    print(newUser)

    with open('customers.json', "r+") as fp:
        data = json.load(fp)
        data.update(newUser)
        fp.seek(0)
        json.dump(data, fp)

# Delete account (Unable to Delete whole element. JSON file loses a Key after deletion of different element.
elif selection == '2':
    username = input(f'To delete your account, please enter your username: ')
    with open('customers.json', 'r+') as fp:
        data = json.load(fp)
        fp.seek(0)
        del data[username]
        json.dump(data, fp)

# Make Transactions
elif selection == '3':
    username = input('Please enter a username: ')

    tries = 1
    max_tries = 3
    pin_tries = 1

    while tries <= max_tries:
        # Print bank title and menu
        print(f'Cactus Bank - Making Transactions\n\n')
        selection = input('Enter pin or x to exit application: ').casefold()

        # determine exit, pin not found, or correct pin found
        if selection == 'x':
            break
        # Verify entered pin is a key in accounts
        elif int(selection) != data[username]['pin']:
            # clear screen - cls for windows and clear for linux or os x
            os.system('cls')
            # os.system('clear') for mac users

            print(f'Invalid pin. Attempt {tries} of {max_tries}. Please Try again')
            if tries == max_tries:
                ans1 = input('Do you want to get a new pin (y/n)?: ').lower()
                if ans1 == 'y':
                    create_pin(username)
                    print(f'You will need to visit the system again to make transactions.')
                    input('Press enter to continue')
                else:
                    print(f'No pin, No account. Sorry.')
            tries += 1
        else:
            # Successful pin entry. reset tries and save pin
            tries = 1
            pin = selection

            os.system('cls')
            # os.system('clear')

            for t in range(1, 4):
                # Welcome customer
                print(f"Welcome {data[username]['Name']}")
                print(f'{"Select Account": ^20}')

                # Prompt for Checking or Savings
                while True:
                    try:
                        selection = input('Enter C or S for (C)hecking or (S)avings: ').upper()
                        if selection != 'C' and selection != 'S':
                            raise ValueError('Incorrect selection.  You must enter C or S.')
                    except ValueError as ex:
                        print(ex)
                    else:
                        os.system('cls')
                        print(f'Opening {selection} Account...\n')
                        break
                # End Prompt Checking or Savings

                print('Transaction instructions:')
                print(' - Withdrawal enter a negative dollar amount: -20.00.')
                print(' - Deposit enter a positive dollar amount: 10.50')

                print(f'\nBalance:  ${data[username][selection]: ,.2f}')
                old_Balance = data[username][selection]
                amount = 0.00
                try:
                    amount = float(input(f'Enter transaction amount: '))

                except (ValueError, TypeError, Exception) as ex:
                    print('Bad Amount - No Transaction.')
                    amount = 0.00

                # Verify enough funds in account
                if (amount + data[username][selection]) >= 0:

                    data[username][selection] = round((data[username][selection] + amount), 2)

                    logger = time.ctime(), username, old_Balance, amount, data[username][selection]

                    jdginn_logger.log_transactions(logger)

                    print(f'Transaction complete. New balance is {data[username][selection]: ,.2f}')
                else:
                    print('Insufficient Funds. Transaction Cancelled.')

                ans = input('Press n to make another transaction or x to exit application: ').casefold()
                if ans[0] == 'x':
                    tries = max_tries + 1
                    break

else:
    print(f'Thank you for visiting. Have a lovely day.')
# end of application loop

print('\n\nSaving data...')
print('\nData Saved.\nExiting...')

with open('customers.json', 'r+') as fp:
    data = json.load(fp)

# Prints Keys with Values in a table.
print(f"{'username':>1}{'pin':>20}{'Name':>20}{'C':>20}{'S':>20}")
for k, v in data.items():
    print(f'{k:>8}', end='')
    for value in v.values():
        print(f'{value:>20}', end='')
    print()

# Beginning of PE7

checking_List = list()
for key in data:
    checking_List.append(data[key]['C'])

# print(checking_List)
print()

checking_Average = statistics.mean(checking_List)
print(f"Checking accounts' average is {format_money(checking_Average)}")

savings_List = list()
for key in data:
    savings_List.append(data[key]['S'])

# print(savings_List)

savings_Average = statistics.mean(savings_List)
print(f"Saving accounts' average is {format_money(savings_Average)}")

print()

above_avg_checking = list(filter(lambda x: x > checking_Average,checking_List))

above_avg_savings = list(filter(lambda x: x > savings_Average, savings_List))

print(f'Customers whose checking account balance is above the average:')
for key in data:
    if data[key]['C'] in above_avg_checking:
        print(f'Username is {key} and name is {data[key]["Name"]}')

print()

print(f'Customers whose savings account balance is above the average:')
for key in data:
    if data[key]['S'] in above_avg_savings:
        print(f'Username is {key} and name is {data[key]["Name"]}')

print()

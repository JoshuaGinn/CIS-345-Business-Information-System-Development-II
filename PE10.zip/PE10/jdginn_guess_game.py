# Joshua Ginn, A5, CIS345, 10:30am

from tkinter import *
from tkinter import ttk
import random




def  reset_game():
    answer.set(random.randint(0,10))
    count.set(0)
    feedback.set('Enter guess 1')
    guess.set('')
    counter.set('')

def check_answer():
    count.set({count}++)


window = Tk()
window.title('Guess Game')
window.geometry("250x195")
window.iconbitmap('pic.ico')



global answer = random.randint(0,3)
global count = 0
global feedback = ""
global guess =
global counter =

menu_bar = Menu(window)
window.config(menu=menu_bar)

file_menu = Menu(menu_bar, tearoff=False)
menu_bar.add_cascade(label='File', menu=file_menu)
file_menu.add_command(label='Reset', command=reset_game)
file_menu.add_command(label='Exit', command=window.quit)

# label
feedback_label = Label(window, textvariable=feedback, justify=LEFT)

# Entry
guess_textBox = Entry(window, textvariable=guess, justify=RIGHT)

# ProgressBar
progress = ttk.Progressbar(window, orient='horizontal', maximum=301, mode='determinate' length=200)

# Label
counter_label = Label(window, textvariable=counter, justify=CENTER)

# Button
submit_button = Button(window, text=Submit, command=check_answer)

#display form
reset_game()
window.mainloop()
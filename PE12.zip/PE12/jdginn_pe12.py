# Joshua Ginn, E12, CIS345, 10:30am

import time

function button_click()









button_click()
clear_checkboxes()


